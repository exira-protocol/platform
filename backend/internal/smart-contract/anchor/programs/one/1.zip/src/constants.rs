pub const MAX_CAP: u64 = 100_000_000_000_000_000; // 6 decimals
pub const MIN_SEED: &[u8] = "asad-mint".as_bytes(); // mint seeds for PDA
